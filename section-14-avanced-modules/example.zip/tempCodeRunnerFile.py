elapsed_time4 = timeit.timeit(stmt2, setup2, number=100000)
print(elapsed_time4)