import pdb
x = [1, 2, 3]
y = 2
z = 3

result = y+z
pdb.set_trace()  # trace to result =y+z
result2 = x+y
